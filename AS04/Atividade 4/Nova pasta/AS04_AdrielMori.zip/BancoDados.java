package org.ufg.dao.database;

import java.sql.Connection;

public interface BancoDados {
    Connection conectar();
}
