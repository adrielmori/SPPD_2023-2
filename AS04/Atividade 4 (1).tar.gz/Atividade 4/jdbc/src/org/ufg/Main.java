package org.ufg;

import org.ufg.Model.Candidato;
import org.ufg.dao.CandidatoDAO;
import org.ufg.dao.factory.MariaDbFactory;

import java.util.Date;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        CandidatoDAO candidatoDAO = new CandidatoDAO(new MariaDbFactory());
        while (true) {
            menu();
            int opcao = leitor.nextInt();
            switch (opcao) {
                case 1 -> candidatoDAO.salvar(cadastar());
                case 2 -> candidatoDAO.listar().forEach(System.out::println);
                case 3 -> System.exit(0);
                default -> System.out.println("Opção inválida");
            }
        }
    }

    static void menu() {
        System.out.println("1 - Cadastrar");
        System.out.println("2 - Listar");
        System.out.println("3 - Sair");
    }

    static Candidato cadastar() {
        Scanner leitor = new Scanner(System.in);
        System.out.println("Digite o nome do candidato: ");
        String nome = leitor.nextLine();
        System.out.println("Digite o sexo do candidato: ");
        char sexo = leitor.next().charAt(0);
        leitor.nextLine();
        System.out.println("Digite a data de nascimento do candidato: ");
        String dataNascimento = leitor.nextLine();
        System.out.println("Digite o cargo pretendido do candidato: ");
        String cargoPretendido = leitor.nextLine();
        System.out.println("Digite o texto do currículo do candidato: ");
        String textoCurriculo = leitor.nextLine();
        return new Candidato(nome, sexo, new Date(dataNascimento), cargoPretendido, textoCurriculo);
    }
}