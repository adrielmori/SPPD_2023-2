package com.ufg.dao.factory;

import com.ufg.dao.database.BancoDados;
import com.ufg.dao.database.Postgres;

public class PostgresFactory extends BancoFactory {
    @Override
    protected BancoDados criarBancoDados() {
        return Postgres.getInstance();
    }
}
