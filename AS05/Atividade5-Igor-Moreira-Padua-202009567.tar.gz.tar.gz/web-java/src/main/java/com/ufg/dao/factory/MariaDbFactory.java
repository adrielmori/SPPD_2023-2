package com.ufg.dao.factory;

import com.ufg.dao.database.BancoDados;
import com.ufg.dao.database.MariaDb;

public class MariaDbFactory extends BancoFactory {
    @Override
    protected BancoDados criarBancoDados() {
        return MariaDb.getInstance();
    }
}
