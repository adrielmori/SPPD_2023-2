package com.ufg.dao.factory;

import com.ufg.dao.database.BancoDados;

public abstract class BancoFactory {
    public BancoDados iniciarBancoDados() {
        return criarBancoDados();
    }

    protected abstract BancoDados criarBancoDados();
}
